package com.mistercoding.infosphere.db

import androidx.room.TypeConverter
import com.mistercoding.infosphere.models.Source

class Converters {
    @TypeConverter
    fun FromSource(source: Source) : String {
        return source.name
    }
    @TypeConverter
    fun toSource(name : String) : Source {
        // we dont need source id so mention two times name
        return Source(name,name)
    }
}