package com.mistercoding.infosphere.db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.mistercoding.infosphere.models.Article

@Dao
interface ArticleDAO {

    // onconclict means if already pk exist then old data replace with
    // new data
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(article: Article) : Long

    @Query("SELECT * FROM articles")
    fun getAllArticles(): LiveData<List<Article>>

    @Delete
    // suspend fun make sure database operations are performed on
    // background threads
    suspend fun deleteArticle(article: Article)
}