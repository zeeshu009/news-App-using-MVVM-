package com.mistercoding.infosphere.api

import com.mistercoding.infosphere.models.NewsResponse
import com.mistercoding.infosphere.utils.Constants.Companion.API_KEY
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

// this class handle entry point or on which base search or get request
interface NewsAPI {
    // GET for entry point here is top headlines
    @GET("v2/top-headlines")
    // get all headlines for us country display page 1 and provide api key
    // every entry point has a suspend fucntions
    // query for display on which bases
    suspend fun getHeadlines(
        @Query("country")
        countryCode : String = "us",
        @Query("page")
        // pageNumber,countryCode,api key are the parameters for headlines
        pageNumber : Int = 1,
        @Query("apikey")
        apiKey : String = API_KEY
    ):Response<NewsResponse>

    @GET("v2/everything")
    suspend fun SearchForNews(
        @Query("q")
        searchQuery : String,
        @Query("page")
        pageNumber : Int = 1,
        @Query("apikey")
        apiKey : String = API_KEY
    ):Response<NewsResponse>
}