package com.mistercoding.infosphere.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.mistercoding.infosphere.models.Article
import java.util.concurrent.locks.Lock

@Database(
    entities = [Article::class],
    version = 1
)
@TypeConverters(Converters::class)
abstract class ArticleDatabase : RoomDatabase(){
    abstract fun getArticleDAO() : ArticleDAO

    companion object{
        // volatile insure that changes by one thread imegatily visible by
        // other thread
        // instance varible used for singleton objects
        @Volatile
        private var instance : ArticleDatabase ? = null
        private val LOCK = Any()

        //it allow us to create instance of article database
        // it follow the singleton pattern mean only one object is created
        operator fun invoke(context: Context) = instance ?: synchronized(LOCK){
            instance?: createDataBase(context).also{
                instance = it
            }
        }
        private fun createDataBase(context: Context) =
            Room.databaseBuilder(context.applicationContext,
                ArticleDatabase::class.java,
                "article_db.db"
            ).build()
    }


}