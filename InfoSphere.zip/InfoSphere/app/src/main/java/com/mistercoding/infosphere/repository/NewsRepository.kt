package com.mistercoding.infosphere.repository

import com.mistercoding.infosphere.api.RetrofitInstance
import com.mistercoding.infosphere.db.ArticleDatabase
import com.mistercoding.infosphere.models.Article

class NewsRepository(val db : ArticleDatabase) {

    suspend fun getHeadlines(countryCode : String,pageNumber:Int) =
        RetrofitInstance.api.getHeadlines(countryCode,pageNumber)

    suspend fun searchNews(searchQuery:String,pageNumber: Int) =
        RetrofitInstance.api.SearchForNews(searchQuery,pageNumber)

    suspend fun upsert(article: Article) = db.getArticleDAO().upsert(article)

    fun getFavouriteNews() = db.getArticleDAO().getAllArticles()

    suspend fun deleteArticle(article: Article) = db.getArticleDAO().deleteArticle(article)
}