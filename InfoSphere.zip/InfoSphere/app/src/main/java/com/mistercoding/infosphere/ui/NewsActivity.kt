package com.mistercoding.infosphere.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.example.newsprojectpractice.R
import com.example.newsprojectpractice.databinding.ActivityNewsBinding
import com.mistercoding.infosphere.db.ArticleDatabase
import com.mistercoding.infosphere.repository.NewsRepository
import com.mistercoding.infosphere.ui.fragments.ArticleFragment
import com.mistercoding.infosphere.ui.fragments.FavouritesFragment
import com.mistercoding.infosphere.ui.fragments.HeadlinesFragment
import com.mistercoding.infosphere.ui.fragments.SearchFragment

class NewsActivity : AppCompatActivity() {
    lateinit var newsViewModel: NewsViewModel
    private lateinit var binding: ActivityNewsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val newsRepository = NewsRepository(ArticleDatabase(this))
        val viewModelProviderFactory = NewsViewModelProviderFactory(application,newsRepository)

        newsViewModel = ViewModelProvider(this,viewModelProviderFactory).get(NewsViewModel::class.java)

        val navHostFragment = supportFragmentManager.findFragmentById(R.id.newsNavHostFragment) as NavHostFragment
        val navController = navHostFragment.navController
        binding.bottomNavigationView.setupWithNavController(navController)


        val firstFragment= HeadlinesFragment()
        val secondFragment=FavouritesFragment()
        val thirdFragment=SearchFragment()


        binding.bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.headlinesFragment -> {
                    setCurrentFragment(firstFragment)
                    true
                }
                R.id.favouritesFragment -> {
                    setCurrentFragment(secondFragment)
                    true
                }
                R.id.searchFragment -> {
                    setCurrentFragment(thirdFragment)
                    true
                }
                else -> false // Return false if the item ID is not handled
            }
        }


    }
    private fun setCurrentFragment(fragment: Fragment)=
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.newsNavHostFragment,fragment)
            commit()
        }
}
